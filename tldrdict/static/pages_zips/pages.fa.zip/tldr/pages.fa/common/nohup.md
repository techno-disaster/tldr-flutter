# nohup

> اجرای یک پردازش در پس زمینه حتی زمانی که ترمینال بسته شود.
> اطلاعات بیشتر: <https://www.gnu.org/software/coreutils/nohup>.

- اجرای پردازش در پس زمینه فارغ از اجرا بودن ترمینال:

`nohup {{command}} {{command_options}}`
