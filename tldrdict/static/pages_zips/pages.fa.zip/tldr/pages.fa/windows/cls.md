# cls

> پاک کردن صفحه.
> اطلاعات بیشتر: <https://docs.microsoft.com/windows-server/administration/windows-commands/cls>.

- پاک کردن صفحه:

`cls`
