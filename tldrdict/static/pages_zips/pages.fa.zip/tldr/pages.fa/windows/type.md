# type

> نمایش محتویات فایل.
> اطلاعات بیشتر: <https://docs.microsoft.com/windows-server/administration/windows-commands/type>.

- نمایش محتویات فایل مشخص شده:

`type {{path/to/file}}`
