# cuninst

> Эта команда — псевдоним для `choco uninstall`.

- Смотри документацию для оригинальной команды:

`tldr choco uninstall`
