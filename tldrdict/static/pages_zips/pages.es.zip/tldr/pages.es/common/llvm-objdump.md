# llvm-objdump

> Este comando es un alias de `objdump`.

- Ver documentación para el comando original:

`tldr objdump`
