# mscore

> Este comando es un alias de `musescore`.

- Ver documentación para el comando original:

`tldr musescore`
