# vimtutor

> Vim tutor, enseña los comandos básicos de vim.

- Ejecuta vim tutor utilizando el idioma especificado (en, es, de, ...):

`vimtutor {{idioma}}`

- Sale del tutor:

`<Esc> :q <Enter>`
