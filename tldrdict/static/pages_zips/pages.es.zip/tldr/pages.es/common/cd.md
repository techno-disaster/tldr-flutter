# cd

> Cambiar el directorio de trabajo.
> Más información: <https://manned.org/cd>.

- Accede al directorio especificado:

`cd {{ruta/al/directorio}}`

- Accede al directorio *home* del usuario actual:

`cd`

- Accede al directorio padre del directorio actual:

`cd ..`

- Accede al directorio elegido previamente:

`cd -`
