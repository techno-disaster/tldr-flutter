# piodebuggdb

> Este comando es un alias de `pio debug`.

- Ver documentación para el comando original:

`tldr pio debug`
