# fortune

> Imprime por pantalla una cita aleatoria (al estilo de una galleta de la suerte).
> Más información: <https://man.archlinux.org/man/fortune.6>.

- Imprime por pantalla una cita:

`fortune`

- Imprime por pantalla una cita ofensiva:

`fortune -o`

- Imprime por pantalla una cita larga:

`fortune -l`

- Imprime por pantalla una cita corta:

`fortune -s`

- Muestra una lista de los archivos de citas disponibles:

`fortune -f`

- Imprime por pantalla una cita de uno de los archivos mostrados en `fortune -f`:

`fortune {{archivo}}`
