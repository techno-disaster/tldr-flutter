# pio-init

> Este comando es un alias de `pio project`.

- Ver documentación para el comando original:

`tldr pio project`
