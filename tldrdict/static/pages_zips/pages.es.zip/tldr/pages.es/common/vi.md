# vi

> Este comando es un alias de `vim`.

- Ver documentación para el comando original:

`tldr vim`
