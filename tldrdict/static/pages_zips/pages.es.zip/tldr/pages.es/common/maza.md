# maza

> Bloqueador en local de anuncios. Como Pi-hole pero local y usando el sistema operativo.
> Más información: <https://github.com/tanrax/maza-ad-blocking>.

- Actualiza la base de datos de Maza:

`maza update`

- Inicia Maza:

`sudo maza start`

- Para Maza:

`sudo maza stop`

- Muestra el estado de Maza:

`maza status`
