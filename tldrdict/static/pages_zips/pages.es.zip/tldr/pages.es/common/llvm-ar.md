# llvm-ar

> Este comando es un alias de `ar`.

- Ver documentación para el comando original:

`tldr ar`
