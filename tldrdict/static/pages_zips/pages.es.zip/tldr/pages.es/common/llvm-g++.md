# llvm-g++

> Este comando es un alias de `clang++`.

- Ver documentación para el comando original:

`tldr clang++`
