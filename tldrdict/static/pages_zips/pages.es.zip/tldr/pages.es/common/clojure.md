# clojure

> Este comando es un alias de `clj`.

- Ver documentación para el comando original:

`tldr clj`
