# llvm-strings

> Este comando es un alias de `strings`.

- Ver documentación para el comando original:

`tldr strings`
