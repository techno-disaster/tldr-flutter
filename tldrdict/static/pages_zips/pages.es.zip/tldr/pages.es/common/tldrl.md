# tldrl

> Este comando es un alias de `tldr-lint`.

- Ver documentación para el comando original:

`tldr tldr-lint`
