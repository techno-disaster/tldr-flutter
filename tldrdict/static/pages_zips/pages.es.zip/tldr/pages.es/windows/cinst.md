# cinst

> Este comando es un alias de `choco install`.

- Ver documentación para el comando original:

`tldr choco install`
