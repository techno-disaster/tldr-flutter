# cuninst

> Este comando es un alias de `choco uninstall`.

- Ver documentación para el comando original:

`tldr choco uninstall`
