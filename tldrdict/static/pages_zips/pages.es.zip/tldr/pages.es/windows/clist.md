# clist

> Este comando es un alias de `choco list`.

- Ver documentación para el comando original:

`tldr choco list`
