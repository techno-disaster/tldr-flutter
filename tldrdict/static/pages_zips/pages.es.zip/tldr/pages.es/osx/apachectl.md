# apachectl

> Interfaz de control pata Apache HTTP Server para macOS.
> Más información: <https://www.unix.com/man-page/osx/8/apachectl/>.

- Inicia la tarea launchd `org.apache.httpd`:

`apachectl start`

- Finaliza la tarea launchd:

`apachectl stop`

- Finaliza e inicia la tarea launchd:

`apachectl restart`
