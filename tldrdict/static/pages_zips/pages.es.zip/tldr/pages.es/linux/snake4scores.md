# snake4scores

> Muestra las máximas puntuaciones del juego snake4.
> Más información: <https://manpages.debian.org/snake4/snake4.6.en.html>.

- Muestra las máximas puntuaciones:

`snake4scores`
