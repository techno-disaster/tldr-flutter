# tcpkill

> Mata la conexiones TCP en curso especificadas.

- Mata las conexiones en curso de una interfaz, máquina y puerto indicados:

`tcpkill -i {{eth1}} host {{192.95.4.27}} and port {{2266}}`
