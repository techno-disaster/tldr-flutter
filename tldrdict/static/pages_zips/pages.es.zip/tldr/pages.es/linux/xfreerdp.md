# xfreerdp

> Implementación libre del protocolo de escritorio remoto (_Remote Desktop Protocol_).
> Más información: <https://www.freerdp.com>.

- Conecta con un servidor FreeRDP:

`xfreerdp /u:{{nombre_de_usuario}} /p:{{contraseña}} /v:{{direccion_ip}}`
