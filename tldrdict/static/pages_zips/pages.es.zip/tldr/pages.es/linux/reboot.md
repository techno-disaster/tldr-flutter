# reboot

> Reinicia la máquina.
> Más información: <https://www.man7.org/linux/man-pages/man8/reboot.8.html>.

- Reinicia inmediatamente:

`reboot`

- Reinicia inmediatamente sin hacer un apagado limpio:

`reboot -f`
