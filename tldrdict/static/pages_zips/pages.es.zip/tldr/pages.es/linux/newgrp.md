# newgrp

> Cambia el grupo primario de pertenencia.

- Cambia el grupo primario de pertenencia del usuario:

`newgrp {{nombre_grupo}}`

- Restablece el grupo primario de pertenencia al grupo por defecto del usuario `/etc/passwd`:

`newgrp`
