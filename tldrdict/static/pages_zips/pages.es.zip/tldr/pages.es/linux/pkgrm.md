# pkgrm

> Elimina un paquete de un sistema CRUX.

- Elimina un paquete instalado:

`pkgrm {{nombre_del_paquete}}`
