# groupdel

> Elimina del sistema grupos de usuarios existentes.
> Más información: <https://manned.org/groupdel>.

- Borra un grupo existente:

`groupdel {{nombre_del_grupo}}`
