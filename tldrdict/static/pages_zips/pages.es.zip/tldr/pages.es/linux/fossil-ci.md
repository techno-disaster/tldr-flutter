# fossil ci

> Este comando es un alias de `fossil commit`.
> Más información: <https://fossil-scm.org/home/help/commit>.

- Ver documentación para el comando original:

`tldr fossil-commit`
