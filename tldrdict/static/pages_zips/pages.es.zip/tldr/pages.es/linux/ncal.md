# ncal

> Este comando es un alias de `cal`.

- Ver documentación para el comando original:

`tldr cal`
