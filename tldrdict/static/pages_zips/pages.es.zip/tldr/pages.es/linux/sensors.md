# sensors

> Proporciona información de los sensores.

- Muestra las lecturas actuales de todos los sensores:

`sensors`

- Muestra las temperaturas en grados Fahrenheit:

`sensors --fahrenheit`
