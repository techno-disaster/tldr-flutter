# ubuntu-bug

> Este comando es un alias de `apport-bug`.

- Ver documentación para el comando original:

`tldr apport-bug`
