# pkgadd

> Añade un paquete a un sistema CRUX.

- Instala un paquete de software local:

`pkgadd {{nombre_paquete}}`

- Actualiza un paquete ya instalado a partir de un paquete local:

`pkgadd -u {{nombre_paquete}}`
