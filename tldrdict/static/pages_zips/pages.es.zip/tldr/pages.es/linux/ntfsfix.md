# ntfsfix

> Arregla problemas habituales de una partición NTFS.

- Arregla una partición NTFS dada:

`sudo ntfsfix {{/dev/sdXN}}`
