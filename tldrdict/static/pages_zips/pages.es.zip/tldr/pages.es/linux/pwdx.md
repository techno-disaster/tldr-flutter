# pwdx

> Muestra el directorio de trabajo de un proceso.

- Muestra el directorio de trabajo actual de un proceso:

`pwdx {{process_id}}`
