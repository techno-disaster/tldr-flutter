# vipw

> Edita el archivo de contraseñas.
> Más información: <https://manned.org/vipw>.

- Edita el archivo de contraseñas:

`vipw`

- Muestra la versión actual de `vipw`:

`vipw --version`
