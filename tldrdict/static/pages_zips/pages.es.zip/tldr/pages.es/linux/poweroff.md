# poweroff

> Apaga la máquina.
> Más información: <https://www.man7.org/linux/man-pages/man8/poweroff.8.html>.

- Apaga la máquina:

`sudo poweroff`
