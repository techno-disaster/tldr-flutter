# llvm-strings

> 這是 `strings` 命令的一個別名。

- 原命令的文檔在：

`tldr strings`
