# platformio

> 這是 `pio` 命令的一個別名。
> 更多資訊：<https://docs.platformio.org/en/latest/core/userguide/>.

- 原命令的文檔在：

`tldr pio`
