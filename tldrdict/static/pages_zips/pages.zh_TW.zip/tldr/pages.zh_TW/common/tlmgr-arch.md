# tlmgr-arch

> 這是 `tlmgr platform` 命令的一個別名。
> 更多資訊：<https://www.tug.org/texlive/tlmgr.html>.

- 原命令的文檔在：

`tldr tlmgr platform`
