# cinst

> 這是 `choco install` 命令的一個別名。

- 原命令的文檔在：

`tldr choco install`
