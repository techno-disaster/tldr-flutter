# ncal

> Perintah ini merupakan alias dari `cal`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr cal`
