# bugreport

> Menunjukkan sebuah laporan masalah bagi Android.
> Perintah ini hanya dapat digunakan di dalam `adb shell`.
> Informasi lebih lanjut: <https://cs.android.com/android/platform/superproject/+/master:frameworks/native/cmds/bugreport>.

- Menunjukkan laporan masalah perangkat Android secara lengkap:

`bugreport`
