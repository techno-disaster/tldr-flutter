# pbpaste

> Mengirim isi papan klip (clipboard) ke output standar.

- Menulis konten papan klip ke dalam sebuah file:

`pbpaste > {{file}}`

- Menggunakan konten papan klip sebagai input bagi sebuah perintah:

`pbpaste | grep foo`
