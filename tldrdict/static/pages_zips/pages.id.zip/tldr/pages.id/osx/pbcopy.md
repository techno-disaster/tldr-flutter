# pbcopy

> Menempatkan output standar pada papan klip (clipboard).

- Menempatkan konten file pada papan klip:

`pbcopy < {{file}}`

- Menempatkan hasil perintah pada papan klip:

`find . -type t -name "*.png" | pbcopy`
