# ver

> Menampilkan nomor versi Windows atau MS-DOS saat ini.
> Informasi lebih lanjut: <https://docs.microsoft.com/windows-server/administration/windows-commands/ver>.

- Menampilkan nomor versi saat ini:

`ver`
