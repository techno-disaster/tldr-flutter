# cls

> Membersihkan layar.
> Informasi lebih lanjut: <https://docs.microsoft.com/windows-server/administration/windows-commands/cls>.

- Bersihkan layar:

`cls`
