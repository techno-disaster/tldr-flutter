# explorer

> Windows File Explorer: penjelajah file pada Windows.
> Informasi Lebih Lanjut: <https://ss64.com/nt/explorer.html>.

- Membuka Windows Explorer:

`explorer`

- Membuka Windows Explorer di direktori saat ini:

`explorer .`

- Membuka Windows Explorer di direktori tertentu:

`explorer {{alamat/ke/direktori}}`
