# cuninst

> Perintah ini merupakan alias dari `choco uninstall`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr choco uninstall`
