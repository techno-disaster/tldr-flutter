# clist

> Perintah ini merupakan alias dari `choco list`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr choco list`
