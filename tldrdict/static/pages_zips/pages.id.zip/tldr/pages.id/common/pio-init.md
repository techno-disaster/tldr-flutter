# pio-init

> Perintah ini merupakan alias dari `pio project`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr pio project`
