# piodebuggdb

> Perintah ini merupakan alias dari `pio debug`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr pio debug`
