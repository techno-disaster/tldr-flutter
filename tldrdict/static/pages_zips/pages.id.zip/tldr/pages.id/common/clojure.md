# clojure

> Perintah ini merupakan alias dari `clj`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr clj`
