# llvm-strings

> Perintah ini merupakan alias dari `strings`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr strings`
