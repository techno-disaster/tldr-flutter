# tlmgr-arch

> Perintah ini merupakan alias dari `tlmgr platform`.
> Informasi lebih lanjut: <https://www.tug.org/texlive/tlmgr.html>.

- Menampilkan dokumentasi untuk perintah asli:

`tldr tlmgr platform`
