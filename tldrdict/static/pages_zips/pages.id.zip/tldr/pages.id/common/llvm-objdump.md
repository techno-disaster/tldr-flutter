# llvm-objdump

> Perintah ini merupakan alias dari `objdump`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr objdump`
