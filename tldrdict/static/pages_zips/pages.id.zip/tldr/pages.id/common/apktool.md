# apktool

> Me-reverse engineer berkas APK.
> Informasi lebih lanjut: <https://ibotpeaches.github.io/Apktool/>.

- Dekode berkas APK:

`apktool d {{berkas.apk}}`

- Men-build folder menjadi berkas APK:

`apktool b {{alamat/ke/direktori}}`

- Menginstal dan menyimpan frameworks:

`apktool if {{framework.apk}}`
