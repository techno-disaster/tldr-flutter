# cola

> Perintah ini merupakan alias dari `git-cola`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr git-cola`
