# llvm-gcc

> Perintah ini merupakan alias dari `clang`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr clang`
