# tldrl

> Perintah ini merupakan alias dari `tldr-lint`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr tldr-lint`
