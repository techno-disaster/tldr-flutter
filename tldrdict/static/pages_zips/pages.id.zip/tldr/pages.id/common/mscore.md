# mscore

> Perintah ini merupakan alias dari `musescore`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr musescore`
