# vi

> Perintah ini merupakan alias dari `vim`.

- Menampilkan dokumentasi untuk perintah asli:

`tldr vim`
