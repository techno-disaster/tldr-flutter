# vue

> CLI serba guna untuk Vue.js.
> Kami mempunyai dokumentasi terpisah untuk menggunakan subperintah seperti `vue build`.
> Informasi lebih lanjut: <https://cli.vuejs.org>.

- Buat proyek vue baru secara interaktif:

`vue create {{nama_proyek}}`

- Buat proyek baru dengan antar muka web:

`vue ui`
