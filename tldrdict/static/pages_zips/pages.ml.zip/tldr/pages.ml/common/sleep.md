# sleep

> കാലതാമസം വരുത്തുവാനുള്ള പ്രോഗ്രാം.
> കൂടുതൽ വിവരങ്ങൾ: <https://www.gnu.org/software/coreutils/manual/html_node/sleep-invocation.html#sleep-invocation>.

- നിമിഷങ്ങൾ വൈകിക്കാൻ:

`sleep {{നിമിഷങ്ങൾ}}`

- മിനിറ്റുകൾ വൈകിക്കാൻ:

`sleep {{മിനിറ്റുകൾ}}m`

- മണിക്കൂറുകൾ വൈകിക്കാൻ:

`sleep {{മണിക്കൂറുകൾ}}h`
