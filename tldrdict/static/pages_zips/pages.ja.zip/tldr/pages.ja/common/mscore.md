# mscore

> このコマンドは `musescore` のエイリアスです.

- オリジナルのコマンドのドキュメントを表示する:

`tldr musescore`
