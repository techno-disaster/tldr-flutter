# llvm-gcc

> このコマンドは `clang` のエイリアスです.

- オリジナルのコマンドのドキュメントを表示する:

`tldr clang`
