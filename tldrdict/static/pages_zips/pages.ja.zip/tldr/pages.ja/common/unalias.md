# unalias

> alias を削除します。

- alias を削除する:

`unalias {{別名}}`

- 全ての alias を削除する:

`unalias -a`
