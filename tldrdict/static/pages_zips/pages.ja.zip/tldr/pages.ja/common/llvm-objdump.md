# llvm-objdump

> このコマンドは `objdump` のエイリアスです.

- オリジナルのコマンドのドキュメントを表示する:

`tldr objdump`
