# platformio

> このコマンドは `pio` のエイリアスです.
> 詳しくはこちら: <https://docs.platformio.org/en/latest/core/userguide/>

- オリジナルのコマンドのドキュメントを表示する:

`tldr pio`
