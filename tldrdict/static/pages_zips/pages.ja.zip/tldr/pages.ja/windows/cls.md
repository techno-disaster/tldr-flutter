# cls

> 画面をクリアします。
> 詳しくはこちら: <https://docs.microsoft.com/windows-server/administration/windows-commands/cls>

- 画面をクリアします:

`cls`
