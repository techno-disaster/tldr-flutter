# choco feature

> Chocolateyで機能を操作します。
> 詳しくはこちら: <https://chocolatey.org/docs/commands-feature>

- 利用可能な機能のリストを表示します:

`choco feature list`

- 機能を有効にします:

`choco feature enable --name {{名}}`

- 機能を無効にします:

`choco feature disable --name {{名}}`
