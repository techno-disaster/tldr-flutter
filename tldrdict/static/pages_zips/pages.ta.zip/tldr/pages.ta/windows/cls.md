# cls

> திரையை அழிக்கிறது.
> மேலும் தகவல்: <https://docs.microsoft.com/windows-server/administration/windows-commands/cls>.

- திரையை அழிக்கவும்:

`cls`
