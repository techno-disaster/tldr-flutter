# bugreport

> Android xatolik xisobotini ko'rsatish.
> Bu buyruq faqat `adb shell` orqali amalga oshiriladi.
> Ko'proq malumot: <https://android.googlesource.com/platform/frameworks/native/+/master/cmds/bugreport/>.

- Android qurulmasida to'liq xatoliklar xabarini ko'rsatish:

`bugreport`
