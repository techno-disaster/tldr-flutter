# bugreportz

> Arxivlangan Android xatolik xisoboti.
> Bu buyruq faqat `adb shell` orqali amalga oshiriladi.
> Ko'proq malumot: <https://android.googlesource.com/platform/frameworks/native/+/master/cmds/bugreportz/>.

- Android qurulmasida to'liq arxivlangan xatoliklar xisobotini yaratish:

`bugreportz`

- Bajarilayotgan `bugreportz` jarayonni progresini ko'rsatish:

`bugreportz -p`

- `bugreportz` ni versiyasini ko'rsatish:

`bugreportz -v`

- Yordam ko'rsatish:

`bugreportz -h`
