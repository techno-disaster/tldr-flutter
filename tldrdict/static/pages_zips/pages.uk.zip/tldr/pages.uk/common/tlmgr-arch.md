# tlmgr-arch

> Ця команда є псевдонімом для `tlmgr platform`.
> Більше інформації: <https://www.tug.org/texlive/tlmgr.html>.

- Дивись документацію для оригінальної команди:

`tldr tlmgr platform`
