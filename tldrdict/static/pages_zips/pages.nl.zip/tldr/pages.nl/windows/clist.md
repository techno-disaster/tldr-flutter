# clist

> Dit commando is een alias van `choco list`.

- Bekijk de documentatie van het originele commando:

`tldr choco list`
