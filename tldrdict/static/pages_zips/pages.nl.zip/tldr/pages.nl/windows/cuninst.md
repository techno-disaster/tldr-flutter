# cuninst

> Dit commando is een alias van `choco uninstall`.

- Bekijk de documentatie van het originele commando:

`tldr choco uninstall`
