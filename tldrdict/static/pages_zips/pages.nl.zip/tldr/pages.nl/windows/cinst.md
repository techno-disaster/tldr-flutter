# cinst

> Dit commando is een alias van `choco install`.

- Bekijk de documentatie van het originele commando:

`tldr choco install`
