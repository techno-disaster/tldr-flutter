# ncal

> Dit commando is een alias van `cal`.

- Bekijk de documentatie van het originele commando:

`tldr cal`
