# unalias

> Verwijder aliassen.

- Verwijder een alias:

`unalias {{alias_naam}}`

- Verwijder alle aliassen:

`unalias -a`
