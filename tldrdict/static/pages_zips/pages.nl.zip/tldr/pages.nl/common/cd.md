# cd

> Verander de huidige map.
> Meer informatie: <https://manned.org/cd>.

- Ga naar de gegeven map:

`cd {{pad/naar/map}}`

- Ga naar de thuismap van de huidige gebruiker:

`cd`

- Ga naar de ouder van de huidige map:

`cd ..`

- Ga naar de vorige map:

`cd -`
