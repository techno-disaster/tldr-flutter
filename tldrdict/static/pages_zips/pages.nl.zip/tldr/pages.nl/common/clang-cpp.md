# clang-cpp

> Dit commando is een alias van `clang++`.

- Bekijk de documentatie van het originele commando:

`tldr clang++`
