# mscore

> Dit commando is een alias van `musescore`.
> Meer informatie: <https://musescore.org/handbook/command-line-options>.

- Bekijk documentatie voor het originele commando:

`tldr musescore`
