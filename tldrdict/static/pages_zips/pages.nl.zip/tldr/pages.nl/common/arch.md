# arch

> Geef de naam van de systeemarchitectuur weer.
> Zie ook `uname`.
> Meer informatie: <https://www.gnu.org/software/coreutils/arch>.

- Geef de architectuur van het systeem weer:

`arch`
