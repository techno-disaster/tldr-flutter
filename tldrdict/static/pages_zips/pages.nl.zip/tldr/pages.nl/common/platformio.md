# platformio

> Dit commando is een alias van `pio`.
> Meer informatie: <https://docs.platformio.org/en/latest/core/userguide/>.

- Bekijk de documentatie van het originele commando:

`tldr pio`
