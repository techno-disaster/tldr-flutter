# chroot

> Voer commando of interactieve shell uit met een speciale hoofdmap.
> Meer informatie: <https://www.gnu.org/software/coreutils/chroot>.

- Voer commando uit met gegeven hoofdmap:

`chroot {{pad/naar/nieuwe/hoofdmap}} {{commando}}`

- Specificeer gebruiker en groep (ID of naam) om te gebruiken:

`chroot --userspec={{gebruiker:groep}}`
