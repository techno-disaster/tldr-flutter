# chsh

> Wijzig de login-shell van de gebruiker.
> Meer informatie: <https://manned.org/chsh>.

- Wijzig shell:

`chsh -s {{pad/naar/shell_binary}} {{gebruikersnaam}}`
