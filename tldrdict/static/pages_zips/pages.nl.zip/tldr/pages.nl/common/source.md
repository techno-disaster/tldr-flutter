# source

> Voer opdrachten uit vanuit een bestand in de huidige shell.

- Evalueer de inhoud van een bepaald bestand:

`source {{pad/naar/bestand}}`
