# view

> Een alleen-lezen versie van `vim`.
> Dit is gelijk aan `vim -R`.

- Open een bestand:

`view {{bestand}}`
