# tlmgr-arch

> Dit commando is een alias van `tlmgr platform`.
> Meer informatie: <https://www.tug.org/texlive/tlmgr.html>.

- Bekijk de documentatie van het originele commando:

`tldr tlmgr platform`
