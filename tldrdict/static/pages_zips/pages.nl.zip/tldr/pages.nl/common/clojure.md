# clojure

> Dit commando is een alias van `clj`.

- Bekijk de documentatie van het originele commando:

`tldr clj`
