# visudo

> Bewerk veilig het sudoers-bestand.

- Bewerk sudoers-bestand:

`sudo visudo`

- Controleer sudoers-bestand op fouten:

`sudo visudo -c`
