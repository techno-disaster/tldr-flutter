# llvm-ar

> Dit commando is een alias van `ar`.

- Bekijk de documentatie van het originele commando:

`tldr ar`
