# time

> Kijk hoe lang een opdracht duurt.

- Tijd "ls":

`time ls`
