# unclutter

> Verbergt de muiscursor.

- Verbergt de muiscursor na 3 seconden:

`unclutter -idle {{3}}`
