# tldr-lint

> `tldr` sayfalarını gözden geçir ve biçimlendir.
> Daha fazla bilgi için: <https://github.com/tldr-pages/tldr-lint>.

- Tüm sayfaları gözden geçir:

`tldr-lint {{sayfa_dizini}}`

- Belirtilmiş bir sayfayı stdout'a biçimlendir:

`tldr-lint --format {{page.md}}`

- Bir konumdaki tüm sayfaları biçimlendir:

`tldr-lint --format --in-place {{sayfa_dizini}}`
