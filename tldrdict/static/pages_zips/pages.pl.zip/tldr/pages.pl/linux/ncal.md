# ncal

> Te polecenie jest aliasem `cal`.

- Zobacz dokumentację orginalnego polecenia:

`tldr cal`
