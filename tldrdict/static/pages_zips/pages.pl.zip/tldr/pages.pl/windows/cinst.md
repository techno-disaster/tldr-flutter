# cinst

> Te polecenie jest aliasem `choco install`.

- Zobacz dokumentację orginalnego polecenia:

`tldr choco install`
