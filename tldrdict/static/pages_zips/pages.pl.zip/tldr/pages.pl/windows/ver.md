# ver

> Wyświetl aktualną wersję systemu DOS lub Windows.
> More information: <https://docs.microsoft.com/windows-server/administration/windows-commands/ver>.

- Wyświetl aktualną wersję systemu:

`ver`
