# cuninst

> Te polecenie jest aliasem `choco uninstall`.

- Zobacz dokumentację orginalnego polecenia:

`tldr choco uninstall`
