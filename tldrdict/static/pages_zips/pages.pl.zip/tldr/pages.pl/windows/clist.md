# clist

> Te polecenie jest aliasem `choco list`.

- Zobacz dokumentację orginalnego polecenia:

`tldr choco list`
