# llvm-objdump

> Te polecenie jest aliasem `objdump`.

- Zobacz dokumentację orginalnego polecenia:

`tldr objdump`
