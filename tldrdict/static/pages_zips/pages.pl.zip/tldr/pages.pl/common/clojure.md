# clojure

> Te polecenie jest aliasem `clj`.

- Zobacz dokumentację orginalnego polecenia:

`tldr clj`
