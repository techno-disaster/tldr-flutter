# vi

> Te polecenie jest aliasem `vim`.

- Zobacz dokumentację orginalnego polecenia:

`tldr vim`
