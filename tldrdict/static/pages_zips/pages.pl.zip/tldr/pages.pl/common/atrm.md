# atrm

> Usuwa zadania o zadanych identyfikatorach (numerach) wcześniej zakolejkowane przez `at` lub `batch`
> Aby znaleźć numery zadań, użyj `atq`.
> Więcej informacji: <https://man.archlinux.org/man/at.1>.

- Usuń zadanie numer 10:

`atrm {{10}}`

- Usuń kilka zadań, oddzielonych spacjami:

`atrm {{15}} {{17}} {{22}}`
