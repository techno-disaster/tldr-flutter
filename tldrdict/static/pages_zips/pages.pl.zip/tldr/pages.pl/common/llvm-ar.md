# llvm-ar

> Te polecenie jest aliasem `ar`.

- Zobacz dokumentację orginalnego polecenia:

`tldr ar`
