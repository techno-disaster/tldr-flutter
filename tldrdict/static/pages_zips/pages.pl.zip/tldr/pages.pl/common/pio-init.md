# pio-init

> Te polecenie jest aliasem `pio project`.

- Zobacz dokumentację orginalnego polecenia:

`tldr pio project`
