# mscore

> Te polecenie jest aliasem `musescore`.

- Zobacz dokumentację orginalnego polecenia:

`tldr musescore`
