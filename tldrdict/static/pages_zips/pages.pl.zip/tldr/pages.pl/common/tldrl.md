# tldrl

> Te polecenie jest aliasem `tldr-lint`.

- Zobacz dokumentację orginalnego polecenia:

`tldr tldr-lint`
