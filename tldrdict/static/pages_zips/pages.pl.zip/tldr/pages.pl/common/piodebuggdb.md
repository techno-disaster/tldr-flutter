# piodebuggdb

> Te polecenie jest aliasem `pio debug`.

- Zobacz dokumentację orginalnego polecenia:

`tldr pio debug`
