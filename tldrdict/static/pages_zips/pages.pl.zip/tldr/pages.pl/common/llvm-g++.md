# llvm-g++

> Te polecenie jest aliasem `clang++`.

- Zobacz dokumentację orginalnego polecenia:

`tldr clang++`
