# platformio

> Te polecenie jest aliasem `pio`.
> Więcej informacji: <https://docs.platformio.org/en/latest/core/userguide/>.

- Zobacz dokumentację orginalnego polecenia:

`tldr pio`
