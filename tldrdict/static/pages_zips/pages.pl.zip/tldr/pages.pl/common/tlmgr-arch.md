# tlmgr-arch

> Te polecenie jest aliasem `tlmgr platform`.
> Więcej informacji: <https://www.tug.org/texlive/tlmgr.html>.

- Zobacz dokumentację orginalnego polecenia:

`tldr tlmgr platform`
