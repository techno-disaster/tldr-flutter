# cola

> Te polecenie jest aliasem `git-cola`.

- Zobacz dokumentację orginalnego polecenia:

`tldr git-cola`
