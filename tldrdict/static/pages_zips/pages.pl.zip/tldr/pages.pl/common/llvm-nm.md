# llvm-nm

> Te polecenie jest aliasem `nm`.

- Zobacz dokumentację orginalnego polecenia:

`tldr nm`
