# vue

> Wielofunkcyjny interfejs CLI dla Vue.js.
> Więcej informacji: <https://cli.vuejs.org>.

- Utwórz nowy projekt vue interaktywnie:

`vue create {{nazwa_projektu}}`

- Utwórz nowy projekt z web UI:

`vue ui`
