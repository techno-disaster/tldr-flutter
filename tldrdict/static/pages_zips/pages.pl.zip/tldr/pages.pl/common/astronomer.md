# astronomer

> Narzędzie wykrywające nielegalne gwiazdki z kont botów w projektach GithHub.
> Więcej informacji: <https://github.com/Ullaakut/astronomer>.

- Skanuj repozytorium:

`astronomer {{tldr-pages/tldr-node-client}}`

- Zeskanuj maksymalną liczbę gwiazdek w repozytorium:

`astronomer {{tldr-pages/tldr-node-client}} --stars {{50}}`

- Przeskanuj repozytorium, w tym raporty porównawcze:

`astronomer {{tldr-pages/tldr-node-client}} --verbose`
