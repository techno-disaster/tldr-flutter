# llvm-strings

> Te polecenie jest aliasem `strings`.

- Zobacz dokumentację orginalnego polecenia:

`tldr strings`
