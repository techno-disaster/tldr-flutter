# istats

> 一个显示 CPU 温度、风扇速度和电池状态等统计数据的命令行工具。
> 更多信息：<https://github.com/Chris911/iStats>.

- 显示所有的统计数据：

`istats`

- 显示所有 CPU 的统计数据：

`istats cpu`

- 显示所有风扇的统计数据：

`istats fan`

- 扫描和打印温度：

`istats scan`
