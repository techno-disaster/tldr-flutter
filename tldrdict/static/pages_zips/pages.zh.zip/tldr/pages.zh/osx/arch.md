# arch

> 显示系统架构的名称，或者在不同的架构下运行命令。
> 另见 `uname`.
> 更多信息：<https://www.unix.com/man-page/osx/1/arch/>.

- 显示系统的架构：

`arch`

- 使用 x86_64 来运行一个命令：

`arch -x86_64 {{命令}}`
