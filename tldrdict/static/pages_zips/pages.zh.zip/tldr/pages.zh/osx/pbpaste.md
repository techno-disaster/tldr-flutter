# pbpaste

> 将剪贴板的内容发送到标准输出（命令行）。

- 将剪贴板的内容写入文件：

`pbpaste > {{文件}}`

- 将剪贴板的内容用作命令的输入：

`pbpaste | grep foo`
