# alpine

> 一个电子邮件客户端和 usenet 新闻组程序，具有 pico/nano 风格的界面。
> 通过 IMAP 支持大多数现代电子邮件服务。

- 正常打开 alpine:

`alpine`

- 直接打开写信息界面，并指定电子邮件发送地址：

`alpine {{邮箱地址}}`

- 退出 alpine:

`'q' 然后 'y'`
