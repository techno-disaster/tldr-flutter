# reboot

> 重新启动系统。
> 更多信息：<https://www.man7.org/linux/man-pages/man8/reboot.8.html>.

- 立即重新启动：

`reboot`

- 立即重启，而无需正常关闭：

`reboot -f`
