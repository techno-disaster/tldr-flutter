# a2dissite

> 在基于 Debian 的操作系统上禁用 Apache 虚拟主机。
> 更多信息：<https://manpages.debian.org/latest/apache2/a2dissite.8.en.html>.

- 禁用虚拟主机：

`sudo a2dissite {{虚拟主机名}}`

- 不显示信息性消息：

`sudo a2dissite --quiet {{虚拟主机名}}`
