# a2disconf

> 在基于 Debian 的操作系统上禁用 Apache 配置文件。
> 更多信息：<https://manpages.debian.org/latest/apache2/a2disconf.8.en.html>.

- 禁用配置文件：

`sudo a2disconf {{配置文件}}`

- 不显示信息性消息：

`sudo a2disconf --quiet {{配置文件}}`
