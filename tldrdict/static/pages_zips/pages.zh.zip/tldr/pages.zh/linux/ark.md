# ark

> KDE 归档工具。
> 更多信息：<https://docs.kde.org/stable5/en/ark/ark/>.

- 将存档解压缩到当前目录：

`ark --batch {{存档名}}`

- 改变解压缩目录：

`ark --batch --destination {{解压缩目录路径}} {{存档名}}`

- 创建一个原本不存在的存档并向它添加文件：

`ark --add-to {{存档名}} {{文件1}} {{文件2}}`
