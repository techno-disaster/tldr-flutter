# poweroff

> 关闭系统。
> 更多信息：<https://www.man7.org/linux/man-pages/man8/poweroff.8.html>.

- 关闭系统电源：

`sudo poweroff`
