# cpuid

> 显示有关所有 CPU 的详细信息。
> 更多信息：<http://etallen.com/cpuid.html>.

- 显示所有 CPU 的信息：

`cpuid`

- 仅显示当前 CPU 的信息：

`cpuid -1`

- 显示原始十六进制信息，不进行解码：

`cpuid -r`
