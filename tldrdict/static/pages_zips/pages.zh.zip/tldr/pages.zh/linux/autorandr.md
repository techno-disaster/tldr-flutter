# autorandr

> 自动调节屏幕布局。
> 更多信息：<https://github.com/phillipberndt/autorandr>.

- 保存当前屏幕布局：

`autorandr -s {{配置文件名}}`

- 显示保存的配置：

`autorandr`

- 切换设置：

`autorandr -l {{配置文件名}}`

- 设置默认设置：

`autorandr -d {{配置文件名}}`
