# a2ensite

> 在基于 Debian 的操作系统上启用 Apache 虚拟主机。
> 更多信息：<https://manpages.debian.org/latest/apache2/a2ensite.8.en.html>.

- 启用虚拟主机：

`sudo a2ensite {{虚拟主机名}}`

- 不显示信息性消息：

`sudo a2ensite --quiet {{虚拟主机名}}`
