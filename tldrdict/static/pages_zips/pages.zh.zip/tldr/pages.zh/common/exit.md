# exit

> 退出终端程序。
> 更多信息：<https://manned.org/exit>.

- 使用最后执行命令的退出代码，退出终端程序：

`exit`

- 使用指定的退出代码，退出终端程序：

`exit {{exit_code}}`
