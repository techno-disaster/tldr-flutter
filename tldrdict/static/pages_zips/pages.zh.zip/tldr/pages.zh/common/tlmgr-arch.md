# tlmgr-arch

> 这是 `tlmgr platform` 命令的一个别名。
> 更多信息：<https://www.tug.org/texlive/tlmgr.html>.

- 原命令的文档在：

`tldr tlmgr platform`
