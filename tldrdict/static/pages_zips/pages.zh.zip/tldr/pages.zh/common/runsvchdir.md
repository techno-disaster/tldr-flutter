# runsvchdir

> 更改默认使用的 `runsvdir` 目录。
> 更多信息：<https://manpages.ubuntu.com/manpages/latest/man8/runsvchdir.8.html>.

- 切换 `runsvdir` 目录：

`sudo runsvchdir {{指定 / 目录}}`
