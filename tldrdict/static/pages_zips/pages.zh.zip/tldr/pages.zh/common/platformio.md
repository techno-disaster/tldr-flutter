# platformio

> 这是 `pio` 命令的一个别名。
> 更多信息：<https://docs.platformio.org/en/latest/core/userguide/>.

- 原命令的文档在：

`tldr pio`
