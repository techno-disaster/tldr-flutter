# unalias

> 移除别名。
> 更多信息：<https://manned.org/unalias>.

- 移除一个别名：

`unalias {{别名}}`

- 移除所有别名：

`unalias -a`
