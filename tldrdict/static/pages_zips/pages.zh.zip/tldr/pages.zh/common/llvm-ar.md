# llvm-ar

> 这是 `ar` 命令的一个别名。

- 原命令的文档在：

`tldr ar`
