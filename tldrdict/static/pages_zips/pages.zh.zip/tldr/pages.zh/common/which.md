# which

> 在用户的`PATH`中寻找可执行文件的路径。

- 在`PATH`中寻找可执行文件并打印第一个匹配的结果：

`which {{executable}}`

- 如果有多个匹配结果则打印所有结果：

`which -a {{executable}}`
