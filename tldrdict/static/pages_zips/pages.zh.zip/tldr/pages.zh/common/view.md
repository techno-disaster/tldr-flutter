# view

> `vim` 的只读版本。
> 等效于 `vim -R`.

- 打开文件：

`view {{file}}`
