# bugreport

> 显示安卓的 Bug 报告。
> 该命令只能通过 `adb shell` 使用。
> 更多信息：<https://cs.android.com/android/platform/superproject/+/master:frameworks/native/cmds/bugreport>.

- 显示 Android 设备的完整错误报告：

`bugreport`
