# dalvikvm

> Android Java 虚拟机。
> 更多信息：<https://source.android.com/devices/tech/dalvik>.

- 启动一个 Java 程序：

`dalvikvm -classpath {{path/to/file.jar}} {{classname}}`
