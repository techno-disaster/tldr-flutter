# wm

> 显示关于 Android 设备屏幕的信息。
> 此命令只能通过 `adb shell` 使用。
> 更多信息：<https://adbinstaller.com/commands/adb-shell-wm-5b672b17e7958178a2955538>.

- 显示 Android 设备屏幕的物理尺寸：

`wm {{size}}`

- 显示 Android 设备屏幕的物理密度：

`wm {{density}}`
