# pwlauncher

> 用于管理 Windows To Go 启动选项的命令行工具。
> 更多信息：<https://docs.microsoft.com/windows-server/administration/windows-commands/pwlauncher>.

- 显示当前 Windows To Go 的状态：

`pwlauncher`

- 启用或禁用 Windows To Go 的启动选项：

`pwlauncher /{{enable|disable}}`
