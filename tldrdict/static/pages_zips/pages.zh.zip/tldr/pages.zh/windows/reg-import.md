# reg import

> 从一个文件导入所有可用的键、子键和值。
> 更多信息：<https://docs.microsoft.com/windows-server/administration/windows-commands/reg-import>.

- 从一个文件导入所有可用的键、子键和值：

`reg import {{reg 文件的路径}}`
