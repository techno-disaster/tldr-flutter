# cls

> 清屏。
> 更多信息：<https://docs.microsoft.com/windows-server/administration/windows-commands/cls>.

- 清屏：

`cls`
