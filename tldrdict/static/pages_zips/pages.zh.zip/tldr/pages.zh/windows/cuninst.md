# cuninst

> 这是 `choco uninstall` 命令的一个别名。

- 原命令的文档在：

`tldr choco uninstall`
