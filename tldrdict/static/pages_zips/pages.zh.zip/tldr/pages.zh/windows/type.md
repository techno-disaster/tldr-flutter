# type

> 显示文件的内容。
> 更多信息：<https://docs.microsoft.com/windows-server/administration/windows-commands/type>.

- 显示特定文件的内容：

`type {{文件的路径}}`
