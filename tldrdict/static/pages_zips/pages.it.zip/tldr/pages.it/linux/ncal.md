# ncal

> Questo comando è un alias per `cal`.

- Consulta la documentazione del comando originale:

`tldr cal`
