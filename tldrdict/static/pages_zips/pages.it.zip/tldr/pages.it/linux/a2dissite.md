# a2dissite

> Disattiva un virtual host Apache su sistemi operativi basati su Debian.
> Maggiori informazioni: <https://manpages.debian.org/latest/apache2/a2dissite.8.en.html>.

- Disattiva un virtual host:

`sudo a2dissite {{virtual_host}}`

- Non mostrare messaggi informativi:

`sudo a2dissite --quiet {{virtual_host}}`
