# a2ensite

> Attiva un virtual host Apache su sistemi operativi basati su Debian.
> Maggiori informazioni: <https://manpages.debian.org/latest/apache2/a2ensite.8.en.html>.

- Attiva un virtual host:

`sudo a2ensite {{virtual_host}}`

- Non mostrare messaggi informativi:

`sudo a2ensite --quiet {{virtual_host}}`
