# a2dismod

> Disattiva un modulo Apache su sistemi operativi basati su Debian.
> Maggiori informazioni: <https://manpages.debian.org/latest/apache2/a2dismod.8.en.html>.

- Disattiva un modulo:

`sudo a2dismod {{modulo}}`

- Non mostrare messaggi informativi:

`sudo a2dismod --quiet {{modulo}}`
