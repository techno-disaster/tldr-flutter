# poweroff

> Chiude il sistema.
> Maggiori informazioni: <https://www.man7.org/linux/man-pages/man8/poweroff.8.html>.

- Spegne il sistema:

`sudo poweroff`
