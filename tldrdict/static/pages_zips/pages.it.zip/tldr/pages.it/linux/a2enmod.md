# a2enmod

> Attiva un modulo Apache su sistemi operativi basati su Debian.
> Maggiori informazioni: <https://manpages.debian.org/latest/apache2/a2enmod.8.en.html>.

- Attiva un modulo:

`sudo a2enmod {{modulo}}`

- Non mostrare messaggi informativi:

`sudo a2enmod --quiet {{modulo}}`
