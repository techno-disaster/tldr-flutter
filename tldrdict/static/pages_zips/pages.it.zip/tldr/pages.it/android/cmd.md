# cmd

> Gestore del servizio Android.
> Maggiori informazioni: <https://cs.android.com/android/platform/superproject/+/master:frameworks/native/cmds/cmd/>.

- Elenca tutti i servizi in esecuzione:

`cmd -l`

- Chiama un servizio specifico:

`cmd {{alarm}}`

- Chiama un servizio con argomenti:

`cmd {{vibrator}} {{vibrate 300}}`
