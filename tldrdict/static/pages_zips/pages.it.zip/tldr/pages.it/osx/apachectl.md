# apachectl

> Interfaccia di controllo del server HTTP Apache per macOS.
> Maggiori informazioni: <https://www.unix.com/man-page/osx/8/apachectl/>.

- Avvia il demone `org.apache.httpd`:

`apachectl start`

- Ferma il demone:

`apachectl stop`

- Riavvia il demone:

`apachectl restart`
