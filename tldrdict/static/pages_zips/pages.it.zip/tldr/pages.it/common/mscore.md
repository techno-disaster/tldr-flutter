# mscore

> Questo comando è un alias per `musescore`.

- Consulta la documentazione del comando originale:

`tldr musescore`
