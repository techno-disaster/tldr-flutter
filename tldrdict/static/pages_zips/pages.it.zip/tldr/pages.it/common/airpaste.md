# airpaste

> Condividi messaggi e file nella stessa rete.
> Maggiori informazioni: <https://github.com/mafintosh/airpaste>.

- Aspetta un messaggo e mostralo una volta ricevuto:

`airpaste`

- Invia un messaggio di testo:

`echo {{messaggio}} | airpaste`

- Invia un file:

`airpaste < {{percorso/al/file}}`

- Ricevi un file:

`airpaste > {{percorso/al/file}}`

- Crea o entra in un canale:

`airpaste {{nome_canale}}`
