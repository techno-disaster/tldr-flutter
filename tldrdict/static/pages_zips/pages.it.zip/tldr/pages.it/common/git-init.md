# git init

> Inizializza un nuovo repository Git locale.
> Maggiori informazioni: <https://git-scm.com/docs/git-init>.

- Inizializza un nuovo repository locale:

`git init`

- Inizializza un repository di soli dati, adatto per essere usato come server remoto accessibile via ssh:

`git init --bare`
