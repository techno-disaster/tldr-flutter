# vi

> Questo comando è un alias per `vim`.

- Consulta la documentazione del comando originale:

`tldr vim`
