# apropos

> Cerca nelle pagine di manuale, ad esempio per trovare un nuovo comando.
> Maggiori informazioni: <https://manned.org/apropos>.

- Cerca una parola chiave:

`apropos {{qualcosa}}`

- Cerca senza limitare l'output alla larghezza del terminale:

`apropos -l {{qualcosa}}`
