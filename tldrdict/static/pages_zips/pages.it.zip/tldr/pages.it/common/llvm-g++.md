# llvm-g++

> Questo comando è un alias per `clang++`.

- Consulta la documentazione del comando originale:

`tldr clang++`
