# atrm

> Rimuovi job programmati dai comandi `at` o `batch`.
> Per trovare i numeri dei job utilizzare `atq`.
> Maggiori informazioni: <https://man.archlinux.org/man/at.1>.

- Rimuovi il job numero 10:

`atrm {{10}}`

- Rimuovi più job, separati da spazi:

`atrm {{15}} {{17}} {{22}}`
