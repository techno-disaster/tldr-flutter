# git repack

> Comprimi gli oggetti decompressi in un repository Git.
> Maggiori informazioni: <https://git-scm.com/docs/git-repack>.

- Comprimi gli oggetti decompressi nella cartella corrente:

`git repack`

- Rimuovi eventuali archivi ridondanti dopo la compressione:

`git repack -d`
