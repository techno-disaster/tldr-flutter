# llvm-objdump

> Questo comando è un alias per `objdump`.

- Consulta la documentazione del comando originale:

`tldr objdump`
