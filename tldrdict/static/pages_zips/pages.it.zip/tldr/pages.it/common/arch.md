# arch

> Mostra il nome dell'architettura del sistema.
> Vedi anche `uname`.
> Maggiori informazioni: <https://www.gnu.org/software/coreutils/arch>.

- Mostra l'architettura del sistema:

`arch`
