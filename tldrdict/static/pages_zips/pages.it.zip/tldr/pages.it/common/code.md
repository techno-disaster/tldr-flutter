# code

> Visual Studio Code.
> Maggiori informazioni: <https://github.com/microsoft/vscode>.

- Apri VS Code:

`code`

- Apri la directory corrente in VS Code:

`code .`

- Apri un file o una directory in VS Code:

`code {{percorso/a/file_o_directory}}`

- Apri un file o una directory nella finestra attualmente aperta di VS Code:

`code --reuse-window {{percorso/a/file_o_directory}}`

- Confronta due file in VS Code:

`code -d {{file1}} {{file2}}`
