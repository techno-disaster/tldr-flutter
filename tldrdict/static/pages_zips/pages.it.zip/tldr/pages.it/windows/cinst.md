# cinst

> Questo comando è un alias per `choco install`.

- Consulta la documentazione del comando originale:

`tldr choco install`
