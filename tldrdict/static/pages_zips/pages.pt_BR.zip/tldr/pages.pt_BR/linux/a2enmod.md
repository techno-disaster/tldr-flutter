# a2enmod

> Ativa um módulo do Apache em sistemas operacionais baseados no Debian.
> Mais informações: <https://manpages.debian.org/latest/apache2/a2enmod.8.en.html>.

- Ativa um módulo:

`sudo a2enmod {{módulo}}`

- Não mostra mensagens informativas:

`sudo a2enmod --quiet {{module}}`
