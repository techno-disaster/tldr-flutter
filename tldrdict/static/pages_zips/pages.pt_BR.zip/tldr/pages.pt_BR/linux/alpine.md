# alpine

> Um cliente de e-mail e programa de newsgroup Usenet com uma interface inspirada no pico e nano.
> Suporta a maioria dos serviços de e-mail por meio de IMAP.

- Iniciar o alpine:

`alpine`

- Abrir o alpine na tela de composição de mensagem com o e-mail do destinatário preenchido:

`alpine {{email@exemplo.net}}`

- Encerrar o alpine:

`'q' e 'y'`
