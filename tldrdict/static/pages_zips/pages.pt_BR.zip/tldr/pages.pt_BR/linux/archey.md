# archey

> Ferramenta que exibe informações do sistema de forma estilizada.
> Mais informações: <https://lclarkmichalek.github.io/archey3/>.

- Exibir as informações do sistema:

`archey`
