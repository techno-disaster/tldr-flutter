# ncal

> Este comando é um pseudônimo de `cal`.

- Ver documentação sobre o comando original:

`tldr cal`
