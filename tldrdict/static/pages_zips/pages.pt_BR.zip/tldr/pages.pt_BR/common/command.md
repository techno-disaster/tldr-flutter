# command

> Obriga o shell a executar o programa, ignorando qualquer função ou alias com o mesmo nome.
> Mais informações: <https://manned.org/command>.

- Executar o programa ls, mesmo que exista algum alias ls:

`command {{ls}}`
