# llvm-ar

> Este comando é um pseudônimo de `ar`.

- Ver documentação sobre o comando original:

`tldr ar`
