# tldrl

> Este comando é um pseudônimo de `tldr-lint`.

- Ver documentação sobre o comando original:

`tldr tldr-lint`
