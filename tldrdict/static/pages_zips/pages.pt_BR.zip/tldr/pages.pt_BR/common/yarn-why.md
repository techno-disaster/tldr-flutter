# yarn-why

> Identifica por que um pacote Yarn foi instalado.
> Mais informações: <https://www.npmjs.com/package/yarn-why>.

- Exibir na tela o motivo de um pacote Yarn estar instalado:

`yarn-why {{nome_do_pacote}}`
