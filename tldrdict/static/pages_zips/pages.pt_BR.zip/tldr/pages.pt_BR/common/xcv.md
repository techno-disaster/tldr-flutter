# xcv

> Corta, copia e cola na linha de comando.
> Mais informações: <https://github.com/busterc/xcv>.

- Cortar um arquivo:

`xcv x {{arquivo_a_ser_cortado}}`

- Copiar um arquivo:

`xcv c {{arquivo_a_ser_copiado}}`

- Colar um arquivo:

`xcv v {{arquivo_a_ser_colado}}`

- Listar todos os arquivos disponíveis para serem colados:

`xcv l`
