# bg

> Retomar a execução, em segundo plano, de processos que foram suspensos (e.g. utilizando `Ctrl + Z`).
> Mais informações: <https://manned.org/bg>.

- Retomar a execução, em segundo plano, do processo que foi suspenso mais recentemente:

`bg`

- Retomar a execução, em segundo plano, de um processo especifico (utilizando `jobs -l` para obter o seu ID):

`bg {{id_processo}}`
