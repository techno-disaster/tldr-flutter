# htop

> Visualizar informação dinâmica em tempo real acerca de processos em execução. Uma versão melhorada do comando `top`.
> Mais informações: <https://htop.dev/>.

- Inicializar htop:

`htop`

- Inicializar htop mostrando somente processos pertencentes a um usuário:

`htop -u {{nome_usuário}}`

- Obter ajuda acerca de comandos interativos:

`?`
