# vi

> Este comando é um pseudônimo de `vim`.

- Ver documentação sobre o comando original:

`tldr vim`
