# xkill

> Termina o cliente associado a um elemento gráfico.
> Utilizado para forçar a terminação de processos que não respondem ou não apresentam botão "fechar".
> Mais informações: <https://www.x.org/releases/current/doc/man/man1/xkill.1.xhtml>.

- Ativar um cursor para fechar uma janela com o clique do botão esquerdo do mouse (pressionar qualquer outro botão para cancelar):

`xkill`
