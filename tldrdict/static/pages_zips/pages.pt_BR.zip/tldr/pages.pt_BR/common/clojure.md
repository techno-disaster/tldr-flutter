# clojure

> Este comando é um pseudônimo de `clj`.

- Ver documentação sobre o comando original:

`tldr clj`
