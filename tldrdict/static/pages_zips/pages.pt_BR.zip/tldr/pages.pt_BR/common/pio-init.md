# pio-init

> Este comando é um pseudônimo de `pio project`.

- Ver documentação sobre o comando original:

`tldr pio project`
