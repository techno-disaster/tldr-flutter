# airpaste

> Compartilhar mensagens e arquivos na mesma rede.
> Mais informações: <https://github.com/mafintosh/airpaste>.

- Esperar por mensagens e mostrá-las quando recebidas:

`airpaste`

- Enviar texto:

`echo {{texto}} | airpaste`

- Enviar arquivo:

`airpaste < {{caminho/para/arquivo}}`

- Receber arquivo:

`airpaste > {{caminho/para/arquivo}}`

- Criar/Entrar em canal:

`airpaste {{nome_do_canal}}`
