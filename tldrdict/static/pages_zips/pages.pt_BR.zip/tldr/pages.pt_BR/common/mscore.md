# mscore

> Este comando é um pseudônimo de `musescore`.

- Ver documentação sobre o comando original:

`tldr musescore`
