# llvm-nm

> Este comando é um pseudônimo de `nm`.

- Ver documentação sobre o comando original:

`tldr nm`
