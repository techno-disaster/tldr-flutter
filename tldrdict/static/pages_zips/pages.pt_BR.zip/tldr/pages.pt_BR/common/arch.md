# arch

> Exibir o nome da arquitetura do sistema.
> Veja também `uname`.
> Mais informações: <https://www.gnu.org/software/coreutils/arch>.

- Exibir a arquitetura do sistema:

`arch`
