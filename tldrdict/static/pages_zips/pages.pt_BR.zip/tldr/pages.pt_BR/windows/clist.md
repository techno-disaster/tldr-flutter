# clist

> Este comando é um pseudônimo de `choco list`.

- Ver documentação sobre o comando original:

`tldr choco list`
