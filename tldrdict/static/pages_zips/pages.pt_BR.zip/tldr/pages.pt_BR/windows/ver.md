# ver

> Exibe a atual versão do Windows ou MS-DOS.
> Mais informações: <https://docs.microsoft.com/windows-server/administration/windows-commands/ver>.

- Mostra a atual versão:

`ver`
