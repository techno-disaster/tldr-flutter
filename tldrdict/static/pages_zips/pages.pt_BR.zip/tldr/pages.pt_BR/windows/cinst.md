# cinst

> Este comando é um pseudônimo de `choco install`.

- Ver documentação sobre o comando original:

`tldr choco install`
