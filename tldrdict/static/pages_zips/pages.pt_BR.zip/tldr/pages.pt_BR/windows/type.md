# type

> Mostrar o conteúdo de um arquivo.
> Mais informações: <https://docs.microsoft.com/windows-server/administration/windows-commands/type>.

- Mostrar o conteúdo de um arquivo específico:

`type {{caminho/para/arquivo}}`
