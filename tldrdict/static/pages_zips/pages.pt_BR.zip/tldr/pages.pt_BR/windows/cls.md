# cls

> Limpar a tela de saída.
> Mais informações: <https://docs.microsoft.com/windows-server/administration/windows-commands/cls>.

- Limpar a tela:

`cls`
