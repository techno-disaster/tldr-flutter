# mkdir

> Criar um diretório.
> Mais informações: <https://docs.microsoft.com/windows-server/administration/windows-commands/mkdir>.

- Criar um diretório:

`mkdir {{nome_do_diretorio}}`

- Criar recursivamente uma árvore de diretórios aninhados:

`mkdir {{caminho/para/subdiretorio}}`
