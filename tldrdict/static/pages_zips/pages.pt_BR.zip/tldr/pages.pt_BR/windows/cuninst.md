# cuninst

> Este comando é um pseudônimo de `choco uninstall`.

- Ver documentação sobre o comando original:

`tldr choco uninstall`
