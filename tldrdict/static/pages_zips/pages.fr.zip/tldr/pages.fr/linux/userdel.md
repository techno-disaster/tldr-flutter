# userdel

> Efface un utilisateur.
> Plus d'informations : <https://manned.org/userdel>.

- Efface un utilisateur et son dossier home :

`userdel -r {{nom}}`
