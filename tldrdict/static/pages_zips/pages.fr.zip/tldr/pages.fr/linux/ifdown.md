# ifdown

> Désactive des interfaces réseau.
> Plus d'informations : <https://manned.org/ifdown>.

- Désactive l'interface eth0 :

`ifdown {{eth0}}`

- Désactive toutes les interfaces déjà actives :

`ifdown -a`
