# bugreport

> Affiche un rapport de bug Android.
> Cette commande peut être utilisé uniquement depuis `adb shell`.
> Plus d'informations : <https://android.googlesource.com/platform/frameworks/native/+/master/cmds/bugreport/>.

- Affiche un rapport de bug d'un appareil Android :

`bugreport`
