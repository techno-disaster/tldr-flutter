# mscore

> Cette commande est un alias de `musescore`.

- Voir la documentation de la commande originale :

`tldr musescore`
