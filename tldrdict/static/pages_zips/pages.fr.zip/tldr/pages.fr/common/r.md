# r

> Interpréteur pour le langage R.
> Plus d'informations : <https://www.r-project.org>.

- Démarre une session de commande R (REPL) :

`R`

- Vérifie la version de R :

`R --version`

- Exécute un fichier :

`R -f {{fichier.R}}`
