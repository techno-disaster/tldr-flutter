# platformio

> Cette commande est un alias de `pio`.
> Plus d'informations : <https://docs.platformio.org/en/latest/core/userguide/>.

- Voir la documentation de la commande originale :

`tldr pio`
