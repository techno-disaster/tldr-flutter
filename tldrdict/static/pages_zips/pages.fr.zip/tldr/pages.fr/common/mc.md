# mc

> Midnight Commander, gestionnaire de fichiers à base de console.
> La navigation dans les répertoires se fait à l'aide des touches directionnelles ou la souris, ou bien en tapant des commandes dans la console.
> Plus d'informations : <https://midnight-commander.org>.

- Démarre `mc` :

`mc`

- Démarre `mc` en mode noir et blanc :

`mc -b`
