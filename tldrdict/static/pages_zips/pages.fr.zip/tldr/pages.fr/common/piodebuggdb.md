# piodebuggdb

> Cette commande est un alias de `pio debug`.

- Voir la documentation de la commande originale :

`tldr pio debug`
