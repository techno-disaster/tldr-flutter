# pwd

> Affiche le nom du répertoire actuel.
> Plus d'informations : <https://www.gnu.org/software/coreutils/pwd>.

- Affiche le répertoire actuel :

`pwd`

- Affiche le répertoire actuel tout en traduisant les liens symboliques (c.-à-d. afficher le répertoire « physique ») :

`pwd -P`
