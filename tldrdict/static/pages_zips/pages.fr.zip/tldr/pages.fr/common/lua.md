# lua

> Un langage de programmation puissant, léger, et convenable aux systèmes embarqués.
> Plus d'informations : <https://www.lua.org>.

- Démarre une session de commandes interactive Lua :

`lua`

- Exécute un script Lua :

`lua {{nom_du_script.lua}} {{--arguments-facultatifs}}`

- Exécute une expression Lua :

`lua -e '{{print( "Hello World" )}}'`
