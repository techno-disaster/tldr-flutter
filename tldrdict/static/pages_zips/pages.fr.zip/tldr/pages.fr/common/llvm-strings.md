# llvm-strings

> Cette commande est un alias de `strings`.

- Voir la documentation de la commande originale :

`tldr strings`
