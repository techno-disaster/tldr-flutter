# xed

> Abre ficheiros para editar no Xcode.

- Abre um ficheiro no Xcode:

`xed {{ficheiro1}}`

- Abre um ou mais ficheiros no Xcode, cria o ficheiro se o mesmo não existir:

`xed -c {{ficheiro1}}`

- Abre um ficheiro no Xcode e foca na linha 88:

`xed -l 88 {{ficheiro}}`
