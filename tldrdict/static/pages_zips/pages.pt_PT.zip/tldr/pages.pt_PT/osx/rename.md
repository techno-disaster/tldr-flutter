# rename

> Altera o nome de um ficheiro ou grupo de ficheiros com uma expressão regular.

- Altera "antes" para "depois" o nome dos ficheiros especificados:

`rename 's/{{antes}}/{{depois}}/' {{*.txt}}`
