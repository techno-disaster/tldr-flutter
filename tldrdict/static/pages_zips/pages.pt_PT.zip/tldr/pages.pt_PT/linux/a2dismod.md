# a2dismod

> Desactiva um módulo do Apache em distribuições baseadas em Debian.
> Mais informações: <https://manpages.debian.org/latest/apache2/a2dismod.8.en.html>.

- Desactiva um módulo:

`sudo a2dismod {{módulo}}`

- Desactiva um módulo, sem mostrar as mensagens informativas:

`sudo a2dismod --quiet {{módulo}}`
