# a2enconf

> Activa um ficheiro de configuração do Apache em distribuições baseadas em Debian.
> Mais informações: <https://manpages.debian.org/latest/apache2/a2enconf.8.en.html>.

- Activa um ficheiro de configuração:

`sudo a2enconf {{ficheiro_de_configuração}}`

- Activa um ficheiro de configuração, sem mostrar as mensagens informativas:

`sudo a2enconf --quiet {{ficheiro_de_configuração}}`
