# a2ensite

> Activa um host virtual do Apache em distribuições baseadas em Debian.
> Mais informações: <https://manpages.debian.org/latest/apache2/a2ensite.8.en.html>.

- Activa um host virtual:

`sudo a2ensite {{virtual_host}}`

- Activa um host virtual, sem mostrar as mensagens informativas:

`sudo a2ensite --quiet {{virtual_host}}`
