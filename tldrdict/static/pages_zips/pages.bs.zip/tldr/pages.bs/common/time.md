# time

> Vidi koliko dugo traje komanda.

- Vrijeme `ls`:

`time ls`
