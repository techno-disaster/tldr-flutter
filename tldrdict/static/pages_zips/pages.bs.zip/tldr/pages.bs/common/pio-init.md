# pio init

> Ova komanda je pseudonim za `pio project init`.

- Pregledaj dokumentaciju za izvornu komandu:

`tldr pio project`
