# tty

> Vraća ime terminala.
> Više informacija: <https://www.gnu.org/software/coreutils/tty>.

- Ispiši ime fajla ovog terminala:

`tty`
