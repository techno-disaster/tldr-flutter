# unclutter

> Skriva kursor miša.

- Sakrij kursor miša nakon 3 sekunde:

`unclutter -idle {{3}}`
