# view

> Read-only verzija `vim`.
> Ovo je ekvivalent za `vim -R`.

- Otvori datoteku:

`view {{datoteka}}`
