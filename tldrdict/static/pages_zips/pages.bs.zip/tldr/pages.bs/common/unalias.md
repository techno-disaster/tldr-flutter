# unalias

> Ukloni pseudonime.

- Ukloni pseudonim:

`unalias {{ime_alijasa}}`

- Ukloni sve pseudonime:

`unalias -a`
