# clist

> Ova komanda je pseudonim za `choco list`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr choco list`
