# cinst

> Ova komanda je pseudonim za `choco install`.

- Pogledaj dokumentaciju za izvornu komandu:

`tldr choco install`
