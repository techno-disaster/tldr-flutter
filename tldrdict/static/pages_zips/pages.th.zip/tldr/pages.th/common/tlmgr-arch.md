# tlmgr-arch

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `tlmgr platform`.
> ดูเพิ่มเติม: <https://www.tug.org/texlive/tlmgr.html>.

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr tlmgr platform`
