# cuninst

> คำสั่งนี้เป็นอีกชื่อหนึ่งของคำสั่ง `choco uninstall`.

- เรียกดูรายละเอียดสำหรับคำสั่งตัวเต็ม:

`tldr choco uninstall`
