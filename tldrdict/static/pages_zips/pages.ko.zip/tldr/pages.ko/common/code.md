# code

> 비주얼 스튜디오 코드.
> 더 많은 정보: <https://github.com/microsoft/vscode>.

- VS Code 열기:

`code`

- 현재 디렉토리에서 VS Code 열기:

`code .`

- 파일이나 디렉토리에서 VS Code 열기:

`code {{경로/파일_혹은_디렉토리}}`

- 현재 열려 있는 VS 코드 창에서 파일 또는 디렉토리를 열기:

`code --reuse-window {{경로/파일_혹은_디렉토리}}`

- 두 개의 VS Code 파일 비교:

`code -d {{파일1}} {{파일2}}`
