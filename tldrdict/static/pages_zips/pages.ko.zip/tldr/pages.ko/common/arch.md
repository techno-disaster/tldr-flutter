# arch

> 시스템 구조의 이름을 보여줍니다.
> `uname` 도 같이 보세요.
> 더 많은 정보: <https://www.gnu.org/software/coreutils/arch>.

- 시스템 구조 보여주기:

`arch`
