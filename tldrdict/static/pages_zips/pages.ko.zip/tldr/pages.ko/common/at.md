# at

> 명령 실행 후 한 번 실행합니다.
> 서비스 AD(또는 ATRUN)는 실제 실행을 위해 실행되어야 합니다.
> 더 많은 정보: <https://man.archlinux.org/man/at.1>.

- 표준 입력에서 명령을 5분 내에 실행(작업이 끝나면 `Ctrl + D` 를 누르세요):

`at now + 5 minutes`

- 오전 10시에 표준 입력에서 명령을 실행하십시오:

`echo "{{./make_db_backup.sh}}" | at 1000`

- 다음 주 화요일에 주어진 파일에서 명령을 실행하십시오:

`at -f {{경로/파일명}} 9:30 PM Tue`
