# consul

> 서비스 검색 기능과 상태 확인을 위한 분산된 키-값(key-value)쌍 저장.
> 더 많은 정보: <https://www.consul.io/commands>.

- Consul 버전을 체크합니다:

`consul --version`

- 일반 도움말을 보여줍니다:

`consul --help`

- 서브 명령어를 위한 도움말을 보여줍니다:

`consul {{하위-명령어}} --help`
