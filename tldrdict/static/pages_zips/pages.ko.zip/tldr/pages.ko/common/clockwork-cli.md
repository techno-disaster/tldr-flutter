# clockwork-cli

> Clockwork PHP 디버깅 프레임워크를 위한 줄 명령어 인터페이스.
> 더 많은 정보: <https://github.com/ptrofimov/clockwork-cli>.

- 현재 프로젝트의 Clockwork 로그들을 모니터링 합니다:

`clockwork-cli`

- 특정 프로젝트의 Clockwork 로그들을 모니터링 합니다:

`clockwork-cli {{경로/디렉토리}}`

- 여러 개의 프로젝트의 Clockwork 로그들을 모니터링 합니다:

`clockwork-cli {{경로/디렉토리1 경로/디렉토리2 …}}`
