# csvpy

> csvkit에 포함된 CSV 파일을 Python 쉘로 로드.
> 더 많은 정보: <https://csvkit.readthedocs.io/en/latest/scripts/csvpy.html>.

- CSV 파일을 `CSVKitReader` 오브젝트에 로드:

`csvpy {{데이터.csv}}`

- CSV 파일을 `CSVKitDictReader` 오브젝트에 로드:

`csvpy --dict {{데이터.csv}}`
