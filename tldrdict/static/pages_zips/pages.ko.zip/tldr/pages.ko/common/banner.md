# banner

> 주어진 인자를 큰 ASCII art로 출력.
> 더 많은 정보: <https://man.archlinux.org/man/banner.1>.

- 텍스트 메시지를 큰 배너로 출력(따옴표는 선택 사항):

`banner "{{Hello World}}"`

- 텍스트 메시지를 너비가 50자인 배너로 출력:

`banner -w {{50}} "{{Hello World}}"`

- stdin에서 텍스트 읽기:

`banner`
