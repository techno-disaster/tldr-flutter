# head

> Prikazuje prvi deo datoteka.
> Više informacija: <https://www.gnu.org/software/coreutils/head>.

- Prikaži prvih nekoliko linija datoteke:

`head -n {{broj_linija}} {{naziv_datoteke}}`

- Prikaži prvih nekoliko bajtova datoteke:

`head -c {{veličina_u_bajtovima}} {{naziv_datoteke}}`

- Prikaži sve osim nekoliko poslednjih linija datoteke:

`head -n -{{broj_linija}} {{naziv_datoteke}}`

- Prikaži sve osim nekoliko poslednjih bajtova datoteke:

`head -c -{{veličina_u_bajtovima}} {{naziv_datoteke}}`
