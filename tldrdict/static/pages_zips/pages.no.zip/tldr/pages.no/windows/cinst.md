# cinst

> Denne kommandoen er et alias for `choco install`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr choco install`
