# cuninst

> Denne kommandoen er et alias for `choco uninstall`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr choco uninstall`
