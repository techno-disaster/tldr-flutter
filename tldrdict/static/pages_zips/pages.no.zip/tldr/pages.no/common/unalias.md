# unalias

> Fjern aliaser.

- Fjern et alias:

`unalias {{alias_navn}}`

- Fjern alle aliaser:

`unalias -a`
