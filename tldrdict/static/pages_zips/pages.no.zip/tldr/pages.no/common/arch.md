# arch

> Vis navnet på systemarkitekturen.
> Se også `uname`.
> Mer informasjon: <https://www.gnu.org/software/coreutils/arch>.

- Vis systemets arkitektur:

`arch`
