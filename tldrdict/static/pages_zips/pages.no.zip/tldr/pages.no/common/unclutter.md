# unclutter

> Gjemmer musepekeren.

- Gjem musepekeren etter 3 sekunder:

`unclutter -idle {{3}}`
