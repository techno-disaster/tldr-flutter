# logname

> Viser brukerens login navn.
> Mer informasjon: <https://www.gnu.org/software/coreutils/logname>.

- Vis brukerens nåværende innloggings navn:

`logname`
