# mscore

> Denne kommandoen er et alias for `musescore`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr musescore`
