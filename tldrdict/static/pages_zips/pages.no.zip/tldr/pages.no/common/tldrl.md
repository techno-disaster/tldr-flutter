# tldrl

> Denne kommandoen er et alias for `tldr-lint`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr tldr-lint`
