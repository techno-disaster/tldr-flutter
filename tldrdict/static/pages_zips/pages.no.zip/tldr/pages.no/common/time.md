# time

> See hvor lang en kommand tar.

- Tid "ls":

`time ls`
