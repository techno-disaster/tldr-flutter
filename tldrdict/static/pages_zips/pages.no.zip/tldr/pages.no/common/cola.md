# cola

> Denne kommandoen er et alias for `git-cola`.

- Vis dokumentasjonen for den opprinnelige kommandoen:

`tldr git-cola`
