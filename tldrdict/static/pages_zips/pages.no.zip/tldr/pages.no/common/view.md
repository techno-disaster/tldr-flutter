# view

> En skrivebeskytter vesjon av `vim`.
> Dette tilsvarer `vim -R`.

- Åpne en fil:

`view {{fil}}`
