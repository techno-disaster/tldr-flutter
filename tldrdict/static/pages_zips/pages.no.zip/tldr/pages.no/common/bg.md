# bg

> Gjenopptar jobber som er suspendert (f.eks. ved hjelp av `Ctrl + Z`), og holder dem i gang i bakgrunnen.
> Mer informasjon: <https://manned.org/bg>.

- Gjenoppta den sist suspenderte jobben og kjør den i bakgrunnen:

`bg`

- Gjenoppta en spesifikk jobb (bruk `jobs -l` for å finne riktig ID) og kjør den i bakgrunnen:

`bg %{{jobb_id}}`
