# ncal

> Det här kommandot är ett alias för `cal`.

- Se dokumentationen för orginalkommandot:

`tldr cal`
