# cuninst

> Det här kommandot är ett alias för `choco uninstall`.

- Se dokumentationen för orginalkommandot:

`tldr choco uninstall`
