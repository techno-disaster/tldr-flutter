# clist

> Det här kommandot är ett alias för `choco list`.

- Se dokumentationen för orginalkommandot:

`tldr choco list`
