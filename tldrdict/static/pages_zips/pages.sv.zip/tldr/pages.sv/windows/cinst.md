# cinst

> Det här kommandot är ett alias för `choco install`.

- Se dokumentationen för orginalkommandot:

`tldr choco install`
