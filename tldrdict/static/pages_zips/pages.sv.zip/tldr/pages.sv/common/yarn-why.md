# yarn-why

> Identifierar varför ett Yarn paket har installerats.
> Mer information: <https://www.npmjs.com/package/yarn-why>.

- Visa varför ett Yarn paket är installerat:

`yarn-why {{paket_namn}}`
