# llvm-g++

> Det här kommandot är ett alias för `clang++`.

- Se dokumentationen för orginalkommandot:

`tldr clang++`
