# kotlin

> Kotlin Programstartare.
> Mer information: <https://kotlinlang.org>.

- Kör en jar fil:

`kotlin {{filnamn.jar}}`

- Visa Kotlin och JVM version:

`kotlin -version`
