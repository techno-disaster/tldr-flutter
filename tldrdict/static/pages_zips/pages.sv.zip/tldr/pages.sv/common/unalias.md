# unalias

> Ta bort alias.

- Ta bort en alias:

`unalias {{alias_namn}}`

- Ta bort alla alias:

`unalias -a`
