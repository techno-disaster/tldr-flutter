# go fix

> Uppdatera paketen för att använda nya API.
> Mer information: <https://golang.org/cmd/go/#hdr-Update_packages_to_use_new_APIs>.

- Uppdatera paketen för att använda nya API:

`go fix {{paketen}}`
