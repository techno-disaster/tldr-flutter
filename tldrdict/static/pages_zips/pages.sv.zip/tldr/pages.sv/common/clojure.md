# clojure

> Det här kommandot är ett alias för `clj`.

- Se dokumentationen för orginalkommandot:

`tldr clj`
