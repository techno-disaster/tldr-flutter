# visudo

> Redigera sudoers-filen på säkert sätt.

- Redigera sudoers-filen:

`sudo visudo`

- Sök fel i sudoers-filen:

`sudo visudo -c`
