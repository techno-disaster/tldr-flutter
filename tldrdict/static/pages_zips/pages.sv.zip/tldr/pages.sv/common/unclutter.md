# unclutter

> Döljer muspekaren.

- Dölj muspekarn efter 3 sekunder:

`unclutter -idle {{3}}`
