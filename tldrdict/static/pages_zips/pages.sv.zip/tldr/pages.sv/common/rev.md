# rev

> Omvänd en textrad.

- Omvänd textraden "hello":

`echo "hello" | rev`

- Omvänd hel fil och skriv till stdout:

`rev {{fil}}`
