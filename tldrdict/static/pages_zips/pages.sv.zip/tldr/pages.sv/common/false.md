# false

> Returnerar en utgångskod på 1.
> Mer information: <https://www.gnu.org/software/coreutils/false>.

- Returnera en utgångskod på 1:

`false`
