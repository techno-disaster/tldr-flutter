# sleep

> Fördröjning under bestämd tid.
> Mer information: <https://www.gnu.org/software/coreutils/sleep>.

- Fördröj i sekunder:

`sleep {{sekunder}}`

- Fördröj i minuter:

`sleep {{minuter}}m`

- Fördröj i timmar:

`sleep {{timmar}}h`
