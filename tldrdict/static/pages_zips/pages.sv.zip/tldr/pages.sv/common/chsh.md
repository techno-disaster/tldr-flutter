# chsh

> Ändra användarens inloggnings-shell.
> Mer information: <https://manned.org/chsh>.

- Ändra shell:

`chsh -s {{väg/till/shell_binär}} {{användarnamn}}`
