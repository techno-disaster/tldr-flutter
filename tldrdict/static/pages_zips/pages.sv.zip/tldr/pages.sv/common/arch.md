# arch

> Visa namnet på systemarkitekturen:
> Se även `uname`.
> Mer information: <https://www.gnu.org/software/coreutils/arch>.

- Visa systemarkitekturen:

`arch`
