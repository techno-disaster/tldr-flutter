# time

> Se hur lång tid ett kommando tar.

- Tidtagning "ls":

`time ls`
