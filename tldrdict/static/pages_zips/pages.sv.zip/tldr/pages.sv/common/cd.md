# cd

> Byt nuvarande katalog.
> Mer information: <https://manned.org/cd>.

- Gå till en given katalog:

`cd {{sökväg/till/katalog}}`

- Gå till hemkatalog för nuvarande användare:

`cd`

- Gå till överordnad katalog:

`cd ..`

- Gå tillbaks till den föregående valda katalogen:

`cd -`
