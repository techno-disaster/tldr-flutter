# cola

> Det här kommandot är ett alias för `git-cola`.

- Se dokumentationen för orginalkommandot:

`tldr git-cola`
