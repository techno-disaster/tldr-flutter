# source

> Kör kommandon från en fil i det aktuella skalet.

- Utvärdera innehållet i en viss fil:

`source {{väg/till/fil}}`
