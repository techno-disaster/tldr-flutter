# tty

> Returnerar terminalnamn.
> Mer information: <https://www.gnu.org/software/coreutils/tty>.

- Skriv ut filnamnet på denna terminal:

`tty`
