# view

> En skrivskyddad version av `vim`.
> Detta är lika med `vim -R`.

- Öppna en fil:

`view {{fil}}`
