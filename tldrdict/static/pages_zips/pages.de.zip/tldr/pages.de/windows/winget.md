# winget

> Windows Package Manager CLI.
> Weitere Informationen: <https://docs.microsoft.com/windows/package-manager/winget>.

- Installiere ein Paket:

`winget install {{paket}}`

- Zeige Informationen über ein Paket an:

`winget show {{paket}}`

- Suche ein Paket:

`winget search {{paket}}`
