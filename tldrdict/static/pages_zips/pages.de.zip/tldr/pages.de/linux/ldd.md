# ldd

> Zeigt Abhängigkeiten von dynamischen Bibliotheken an.
> Weitere Informationen: <https://manned.org/ldd>.

- Zeige Abhängigkeiten von dynamischen Bibliotheken einer Binärdatei an:

`ldd {{pfad/zu/binärdatei}}`

- Zeige ungenutzte direkte Abhängigkeiten an:

`ldd -u {{pfad/zu/binärdatei}}`
