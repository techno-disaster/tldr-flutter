# alpine

> Ein E-Mail und Usenet Client mit pico/nano-inspirierten Interface.
> Unterstützt die meisten modernen IMAP Server.

- Öffne Apline:

`alpine`

- Öffne alpine im E-Mail-Editor, um eine E-Mail an eine bestimmte Adresse zu verfassen:

`alpine {{email@example.net}}`

- Beende Alpine:

`'q', dann 'y'`
