# numlockx

> Steuere den Num-Lock-Tasten-Status in X11-Sitzungen.
> Weitere Informationen: <http://www.mike-devlin.com/linux/README-numlockx.htm>.

- Zeige den aktuellen Status der Num-Lock-Taste an:

`numlockx status`

- Schalte die Num-Lock-Taste ein:

`numlockx on`

- Schalte die Num-Lock-Taste aus:

`numlockx off`

- Schalte die Num-Lock-Taste um:

`numlockx toggle`
