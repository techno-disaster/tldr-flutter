# a2dismod

> Deaktiviert ein Apache Modul auf Debian-basierten Betriebssystemen.
> Weitere Informationen: <https://manpages.debian.org/latest/apache2/a2dismod.8.en.html>.

- Deaktiviere ein Modul:

`sudo a2dismod {{modul}}`

- Zeige keine Informationsnachrichten an:

`sudo a2dismod --quiet {{modul}}`
