# ncal

> Dieser Befehl ist ein Alias von `cal`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr cal`
