# calc

> Ein interaktiver Rechner im Terminal mit beliebiger Genauigkeit.
> Weitere Informationen: <https://github.com/lcn2/calc>.

- Starte calc im interaktiven Modus:

`calc`

- Führe eine nicht-interaktive Berechnung durch:

`calc -p '{{85 * (36 / 4)}}'`
