# archey

> Simples Tool um system informationen stylish zu präsentieren.
> Mehr Informationen: <https://lclarkmichalek.github.io/archey3/>.

- Zeige System Informationen:

`archey`
