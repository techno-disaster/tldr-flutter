# dalvikvm

> Androids Java Virtual Machine.
> Weitere Informationen: <https://source.android.com/devices/tech/dalvik>.

- Starte ein Java-Programm:

`dalvikvm -classpath {{pfad/zu/datei.jar}} {{klassenname}}`
