# llvm-nm

> Dieser Befehl ist ein Alias von `nm`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr nm`
