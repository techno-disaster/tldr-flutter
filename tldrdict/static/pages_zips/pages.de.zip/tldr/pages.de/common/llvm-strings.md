# llvm-strings

> Dieser Befehl ist ein Alias von `strings`.

- Zeige die Dokumentation für den originalen Befehl an:

`tldr strings`
