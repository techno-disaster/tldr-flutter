# chsh

> Ändere die Login-Shell eines Benutzers.
> Weitere Informationen: <https://manned.org/chsh>.

- Ändere die Login-Shell eines Benutzers:

`chsh -s {{pfad/zu/shell}} {{benutzername}}`
