# exit

> Verlasse die Shell.
> Weitere Informationen: <https://manned.org/exit>.

- Beende die Shell mit dem Exitcode des zuletzt ausgeführten Befehls:

`exit`

- Beende die Shell mit dem angegebenen Exitcode:

`exit {{exitcode}}`
