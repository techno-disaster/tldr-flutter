# sleep

> Verzögert für einen bestimmten Zeitraum.
> Weitere Informationen: <https://www.gnu.org/software/coreutils/sleep>.

- Verzögere in Sekunden:

`sleep {{sekunden}}`

- Verzögere in Minuten:

`sleep {{minuten}}m`

- Verzögere in Stunden:

`sleep {{stunden}}h`
