# cd

> Ändere das aktuelle Arbeitsverzeichnis.
> Weitere Informationen: <https://manned.org/cd>.

- Wechsle in das angegebene Verzeichnis:

`cd {{pfad/zu/verzeichnis}}`

- Wechsle in das Home-Verzeichnis des aktuellen Benutzers:

`cd`

- Wechsle zum Verzeichnis über dem aktuellen Verzeichnis:

`cd ..`

- Wechsle zum zuletzt gewählten Verzeichnis:

`cd -`
