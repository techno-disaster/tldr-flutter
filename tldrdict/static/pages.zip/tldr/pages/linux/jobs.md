# jobs

> Shell builtin for viewing information about processes spawned by the current shell.
> Options other than `-l` and `-p` are exclusive to Bash.
> See also: `fg`, `bg`, `disown`, `%`.
> More information: <https://www.gnu.org/software/bash/manual/bash.html#index-jobs>.

- View jobs spawned by the current shell:

`jobs`

- List jobs and their process IDs:

`jobs -l`

- Display information about jobs with changed status:

`jobs -n`

- Display only process IDs:

`jobs -p`

- Display running processes:

`jobs -r`

- Display stopped processes:

`jobs -s`
