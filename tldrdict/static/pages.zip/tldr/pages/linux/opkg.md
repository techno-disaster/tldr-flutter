# opkg

> A lightweight package manager used to install OpenWrt packages.
> More information: <https://openwrt.org/docs/guide-user/additional-software/opkg>.

- Install a package:

`opkg install {{package}}`

- Remove a package:

`opkg remove {{package}}`

- Update the list of available packages:

`opkg update`

- Upgrade one or more specific package(s):

`opkg upgrade {{package1 package2 ...}}`

- Display information for a specific package:

`opkg info {{package}}`

- List all the available packages:

`opkg list`

- Find out which package owns a file:

`opkg search /{{path/to/file}}`

- List all files belonging to a package:

`opkg files {{package}}`
