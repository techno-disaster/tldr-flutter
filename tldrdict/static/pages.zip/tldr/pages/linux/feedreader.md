# feedreader

> A GUI desktop RSS client.
> Note: FeedReader is no longer being maintained.
> More information: <https://manned.org/feedreader>.

- Print the count of unread articles:

`feedreader --unreadCount`

- Add a URL for a feed to follow:

`feedreader --addFeed={{feed_url}}`

- Grab a specific article using its URL:

`feedreader --grabArticle={{article_url}}`

- Download all images from a specific article:

`feedreader --url={{feed_url}} --grabImages={{path/to/article}}`

- Play media from a URL:

`feedreader --playMedia={{article_url}}`
