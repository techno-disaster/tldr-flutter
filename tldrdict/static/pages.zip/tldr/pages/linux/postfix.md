# postfix

> Postfix mail transfer agent (MTA) control program.
> More information: <https://www.postfix.org/postfix.1.html>.

- Check the configuration:

`sudo postfix check`

- Check the status of the Postfix daemon:

`sudo postfix status`

- Start Postfix:

`sudo postfix start`

- Gracefully stop Postfix:

`sudo postfix stop`

- Flush the mail queue:

`sudo postfix flush`

- Reload the configuration files:

`sudo postfix reload`
