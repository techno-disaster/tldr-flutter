# yum

> This command is an alias of `dnf` on modern distros.
> For older distros (e.g. CentOS 7), `yum` is a distinct program from `dnf`. Some subcommands and options may be different.

- View documentation for the original command:

`tldr dnf`
