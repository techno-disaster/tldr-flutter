# debugfs

> An interactive ext2/ext3/ext4 filesystem debugger.
> More information: <https://manned.org/debugfs>.

- Open the filesystem in read only mode:

`debugfs {{/dev/sdXN}}`

- Open the filesystem in read write mode:

`debugfs -w {{/dev/sdXN}}`

- Read commands from a specified file, execute them, and then exit:

`debugfs -f {{path/to/cmd_file}} {{/dev/sdXN}}`

- [Interactive] View the filesystem stats in debugfs console:

`stats`

- [Interactive] Close the filesystem:

`close -a`

- [Interactive] List all available commands:

`lr`
