# lsmod

> Shows the status of Linux kernel modules.
> See also `modprobe`, which loads kernel modules.
> More information: <https://manned.org/lsmod>.

- List all currently loaded kernel modules:

`lsmod`
