# wpa_passphrase

> Generate a WPA-PSK key from an ASCII passphrase for a SSID.
> More information: <https://manned.org/wpa_passphrase.1>.

- Compute and display the WPA-PSK key for a given SSID reading the passphrase from `stdin`:

`wpa_passphrase {{ssid}}`

- Compute and display WPA-PSK key for a given SSID specifying the passphrase as an argument:

`wpa_passphrase {{ssid}} {{passphrase}}`
