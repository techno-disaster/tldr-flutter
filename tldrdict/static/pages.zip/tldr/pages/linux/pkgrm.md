# pkgrm

> Remove a package from a CRUX system.
> More information: <https://docs.oracle.com/cd/E88353_01/html/E72487/pkgrm-8.html>.

- Remove an installed package:

`pkgrm {{package_name}}`
