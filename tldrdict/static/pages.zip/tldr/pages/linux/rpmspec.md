# rpmspec

> Query an RPM spec file.
> More information: <https://manned.org/rpmspec>.

- List binary packages which would be generated from an RPM spec file:

`rpmspec --query {{path/to/rpm.spec}}`

- List all options for `--queryformat`:

`rpmspec --querytags`

- Get summary information for single binary packages generated from an RPM spec file:

`rpmspec --query --queryformat "{{%{name}: %{summary}\n}}" {{path/to/rpm.spec}}`

- Get the source package which would be generated from an RPM spec file:

`rpmspec --query --srpm {{path/to/rpm.spec}}`

- Parse an RPM spec file to `stdout`:

`rpmspec --parse {{path/to/rpm.spec}}`
