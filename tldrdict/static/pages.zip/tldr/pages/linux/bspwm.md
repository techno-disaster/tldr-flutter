# bspwm

> A tiling window manager based on binary space partitioning.
> See also: `bspc`.
> More information: <https://github.com/baskerville/bspwm/blob/master/doc/bspwm.1.asciidoc>.

- Start `bspwm` (note that a pre-existing window manager must not be open when this command is run):

`bspwm -c {{path/to/config}}`
