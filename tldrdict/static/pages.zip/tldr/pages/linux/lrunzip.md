# lrunzip

> This command is an alias of `lrzip --decompress`.

- View documentation for the original command:

`tldr lrzip`
