# lrunzip

> This command is an alias of `lrzip -d`.

- View documentation for the original command:

`tldr lrzip`
