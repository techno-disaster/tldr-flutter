# fprintd

> Fingerprint management daemon.
> More information: <https://fprint.freedesktop.org/>.

- Display the man page for `fprintd`:

`man fprintd`
