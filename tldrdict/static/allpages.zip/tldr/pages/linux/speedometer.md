# speedometer

> Python script that shows a network traffic graph in the terminal.
> More information: <http://excess.org/speedometer>.

- Show graph for a specific interface:

`speedometer -r {{eth0}} -t {{eth0}}`
