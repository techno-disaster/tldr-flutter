# snap

> `snap` can refer to multiple commands with the same name.

- View documentation for the packaging solution:

`tldr snap.pkg`

- View documentation for the European Space Agency Earth observation data processing tool:

`tldr snap.esa`
