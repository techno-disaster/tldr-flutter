# groupdel

> Delete existing user groups from the system.
> More information: <https://manned.org/groupdel>.

- Delete an existing group:

`groupdel {{group_name}}`
