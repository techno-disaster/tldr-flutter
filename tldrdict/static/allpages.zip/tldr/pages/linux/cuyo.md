# cuyo

> Tetris like game.
> More information: <https://www.karimmi.de/cuyo/>.

- Start a new game:

`cuyo`

- Navigate the piece horizontally:

`{{<a>|<d>|<ArrowLeft>|<ArrowRight>}}`

- Turn the piece:

`{{<w>|<ArrowUp>}}`

- Hard drop the piece:

`{{<s>|<ArrowDown>}}`
