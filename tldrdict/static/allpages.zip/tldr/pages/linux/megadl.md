# megadl

> This command is an alias of `megatools-dl`.

- View documentation for the original command:

`tldr megatools-dl`
