# mkfs.minix

> Create a Minix filesystem inside a partition.
> More information: <https://manned.org/mkfs.minix>.

- Create a Minix filesystem inside partition Y on device X:

`sudo mkfs.minix {{/dev/sdXY}}`
