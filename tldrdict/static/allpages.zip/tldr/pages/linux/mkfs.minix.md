# mkfs.minix

> Create a Minix filesystem inside a partition.
> More information: <https://manned.org/mkfs.minix>.

- Create a Minix filesystem inside partition 1 on device b (`sdb1`):

`mkfs.minix {{/dev/sdb1}}`
