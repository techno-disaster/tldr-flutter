# nmcli monitor

> Monitor changes to the NetworkManager connection status.
> More information: <https://networkmanager.pages.freedesktop.org/NetworkManager/NetworkManager/nmcli.html>.

- Start monitoring NetworkManager changes:

`nmcli {{[m|monitor]}}`
