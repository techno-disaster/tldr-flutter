# vrms

> Report non-free packages installed on Debian-based OSes.
> More information: <https://salsa.debian.org/debian/check-dfsg-status>.

- List non-free and contrib packages (and their description):

`vrms`

- Only output the package names:

`vrms --sparse`
