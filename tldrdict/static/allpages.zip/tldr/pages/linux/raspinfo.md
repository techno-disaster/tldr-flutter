# raspinfo

> Display Raspberry Pi system information.
> More information: <https://github.com/raspberrypi/utils/tree/master/raspinfo>.

- Display system information:

`raspinfo`
