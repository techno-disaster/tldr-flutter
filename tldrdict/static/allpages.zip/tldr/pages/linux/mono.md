# mono

> Runtime for the .NET Framework.
> More information: <https://www.mono-project.com/docs/>.

- Run a .NET assembly in debug mode:

`mono --debug {{path/to/program.exe}}`

- Run a .NET assembly:

`mono {{path/to/program.exe}}`
