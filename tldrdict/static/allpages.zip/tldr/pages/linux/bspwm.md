# bspwm

> A tiling window manager based on binary space partitioning.
> See also: `bspc`, for controlling it.
> More information: <https://github.com/baskerville/bspwm>.

- Start `bspwm` (note that a pre-existing window manager must not be open when this command is run):

`bspwm -c {{path/to/config}}`
