# ifup

> Enable network interfaces.
> More information: <https://manned.org/ifup>.

- Enable interface eth0:

`ifup {{eth0}}`

- Enable all the interfaces defined with "auto" in `/etc/network/interfaces`:

`ifup {{[-a|--all]}}`
