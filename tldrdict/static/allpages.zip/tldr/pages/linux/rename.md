# rename

> `rename` can refer to multiple commands with the same name.

- View documentation for the Perl version:

`tldr -p common rename`

- View documentation for the `util-linux` version:

`tldr rename.util`
