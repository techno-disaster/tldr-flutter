# tlp-stat

> A tool to generate TLP status reports.
> See also `tlp`.
> More information: <https://linrunner.de/tlp/usage/tlp-stat>.

- Generate status report with configuration and all active settings:

`sudo tlp-stat`

- Show battery information:

`sudo tlp-stat -b`

- Show configuration:

`sudo tlp-stat -c`
