# i7z

> An Intel CPU (only i3, i5 and i7) realtime reporting tool.
> More information: <https://manned.org/i7z>.

- Start i7z (needs to be run in superuser mode):

`sudo i7z`
