# pw-play

> This command is an alias of `pw-cat --playback`.

- View documentation for the original command:

`tldr pw-cat`
