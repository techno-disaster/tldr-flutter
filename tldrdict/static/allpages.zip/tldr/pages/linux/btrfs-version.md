# btrfs version

> Display btrfs-progs version.
> More information: <https://btrfs.readthedocs.io/en/latest/btrfs.html>.

- Display help:

`btrfs version --help`

- Display btrfs-progs version:

`btrfs version`
