# btrfs version

> Display btrfs-progs version.
> More information: <https://btrfs.readthedocs.io/en/latest/btrfs.html>.

- Display help:

`btrfs {{[v|version]}} --help`

- Display version:

`btrfs {{[v|version]}}`
