# mkfs.vfat

> This command is an alias of `mkfs.fat`.

- View documentation for the original command:

`tldr mkfs.fat`
